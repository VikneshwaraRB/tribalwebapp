<?php
$mus=0;$art=0;$dan=0;$trad=0;$fes=0;$mar=0;
if(isset($_POST['submit'])){
 {
if($_POST['music'] =='Music') 
{
$mus=$mus+1;
}
else 
if($_POST['dance'] =='dance') 
{
$dan=$dan+1;
}
else
if($_POST['art'] =='arts') 
{
$art=$art+1;
}
else
if($_POST['festive'] =='festivals') 
{
$fes=$fes+1;
}
else
if($_POST['traditional'] =='traditional custom') 
{
$trad=$trad+1;
}
else
	{
$mar=$mar+1;
}
	
}


$con=mysqli_connect("localhost","root","","sih");
	$qry="update categ set value =$mus where name="music";
	$result=mysqli_query($con,$qry);
	 	if ($result) 
		{
	 		echo "<br/>value uploaded.";
	 	}
	 	else
	 	{
	       	echo "<br/>value not uploaded.";
	 	}
?>				