<html>
<head>
	<title>category!</title>
	<link rel="stylesheet" type="text/css" href="assets/css/style.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
	<script src="assets/js/register.js"></script>
</head>
<body>
	<div class="wrapper">
		<div class="cat_box">
			<div class="header">
				<h1>category selection</h1>
			</div>
			<br>
			<div id="first">
				<form  action="" method="post">

				<h2><label>your going to say about?</label></h2><br>
				<h3><input type="checkbox" name="art" value="arts"> arts &crafts
        <br>        <input type="checkbox" name="music" value="Music"> Music
	    <br>     	<input type="checkbox" name="dance" value="dance" checked> dance
		<br>		<input type="checkbox" name="festive" value="festivals"> festivals
		<br>	    <input type="checkbox" name="traditional" value="traditional custom"> traditional custom
		<br>        <input type="checkbox" name="marriage" value="marriage"> marriage
		<br></h3>
			</fieldset>
			<br>	<input type="submit" value="proceed">
	
		     </form>

	</div>

</div>
</body>
</html>