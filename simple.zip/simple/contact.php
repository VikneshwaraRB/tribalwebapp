
<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
	<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Contact us</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
<!-- Optional theme -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">
<meta charset="utf-8" />
<meta http-equiv="Content-type" content="text/html" charset="utf-8" />

 
  	<!-- Facebook and Twitter integration -->
	<meta property="og:title" content=""/>
	<meta property="og:image" content=""/>
	<meta property="og:url" content=""/>
	<meta property="og:site_name" content=""/>
	<meta property="og:description" content=""/>
	<meta name="twitter:title" content="" />
	<meta name="twitter:image" content="" />
	<meta name="twitter:url" content="" />
	<meta name="twitter:card" content="" />

	<!-- Place favicon.ico and apple-touch-icon.png in the root directory -->
	<link rel="shortcut icon" href="favicon.ico">

	<link href='https://fonts.googleapis.com/css?family=Work+Sans:400,300,600,400italic,700' rel='stylesheet' type='text/css'>
	
	<!-- Animate.css -->
	<link rel="stylesheet" href="css/animate.css">
	
	<!-- Magnific Popup -->
	<link rel="stylesheet" href="css/magnific-popup.css">
	<!-- Bootstrap  -->
	<link rel="stylesheet" href="css/bootstrap.css">
	<!-- Icomoon Icon Fonts-->
	<link rel="stylesheet" href="css/icomoon.css">
	<!-- Theme style  -->
	<link rel="stylesheet" href="css/style.css">

	<!-- Modernizr JS -->
	<script src="js/modernizr-2.6.2.min.js"></script>
	<!-- FOR IE9 below -->
	<!--[if lt IE 9]>
	<script src="js/respond.min.js"></script>
	<![endif]-->

	</head>
	<body>
	
	<div id="fh5co-wrap">
		<header id="fh5co-header">
			<div class="container">
				<nav class="fh5co-main-nav">
					<ul>
						<li><a href="index.html" target="_blank"><span>Home</span></a></li>
						<li><a href="login.php" target="_blank"><span>Login</span></a></li>
						<li><a href="register.php" target="_blank"><span>Register</span></a></li>
						<li class="fh5co-active"><a href="contact.html" target="_blank"><span>Contact</span></a></li>
					</ul>
				</nav>
			</div>
		</header>

		<div class="fh5co-hero" style="background-image: url(images/hero_3.jpg);" data-stellar-background-ratio="0.5">
			<div class="overlay"></div>
			<div class="container">
				<div class="row">
					<div class="col-md-8 col-md-offset-2 col-sm-12 col-sm-offset-0 col-xs-12 col-xs-offset-0 text-center fh5co-table">
						<div class="fh5co-intro fh5co-table-cell">
							<h1 class="text-center">Grievance redressal</h1>
							<p>Made by Ministry of Tribal Affairs</p>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="fh5co-section">
			<div class="container">
				<div class="row">
					<div class="col-md-5">
						<h2>Contact Us</h2>
						<p></p>

						<p>Dr Rajendra Prasad Road, Rajpath Area,<br> Central Secretariat,<br> New Delhi,<br> Delhi 110001</p>
						<p><a href="#"></a></p>
						<p><a href="#">+098765 43210</a></p>
					</div>
					<div class="col-md-6 col-md-push-1">
						<form  method="post">
							<div class="form-group">
								<input type="text" class="form-control" placeholder="Enter your Name" name="name" required> 
							</div>
							<div class="form-group">
								<input type="text" class="form-control" placeholder="Enter your valid Email" name="email" required>
							</div>
							<div class="form-group">
								<input type="text" class="form-control" placeholder="Enter the Subject" name="subject" required>
							</div>
                            <div class="form-group">
								<textarea class="form-control" cols="30" rows="10" placeholder="Enter the Message" name="message" required></textarea>
							</div>

							<div class="form-group">
								<input type="submit" value="Send Message" name="submit" class="btn btn-primary btn-md">
							</div>
						</form>
					</div>
					</div>
 <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3502.446044442768!2d77.21283135087165!3d28.616390882337956!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390ce2b642a88c03%3A0x959112a754ac6e2b!2sShastri+Bhawan!5e0!3m2!1sen!2sin!4v1518946954036" width="1000" height="600" frameborder="0" style="border:0" allowfullscreen></iframe>
	</div> 
				</div>
			</div>
		</div>
		<div id="map">
			
		!-- END fh5co-wrap -->


	<footer id="fh5co-footer">
		<div class="container">
			<div class="row">
				<div class="col-md-4">
					<h3>About Us</h3>
					<p>This is designed for promoting the heritage and culture of tribal people</p>
				</div>
				<div class="col-md-3 col-md-push-1">
					<h3>Quick Links</h3>
					<ul>
						<li><a href="https://tribal.nic.in/" target="_blank">Tribal Affairs Website</a></li>
						<li><a href="http://tribal.nic.in/repository/" target="_blank">Tribal affairs repository</a></li>
						<li><a href="https://en.wikipedia.org/wiki/Adivasi" target="_blank">Wikipedia</a></li>
						<li><a href="contact.html" target="_blank" >Contact us</a></li>
					</ul>
				</div>
				<div class="col-md-3 col-md-push-1">
					<h3>Follow Us</h3>
					<ul class="fh5co-social">
						<li><a href="https://twitter.com/tribalaffairsin?lang=en" target="_blank"><i class="icon-twitter"></i> <span>Twitter</span></a></li>
						<li><a href="https://www.facebook.com/TribalAffairsIn/"target="_blank"><i class="icon-facebook"></i> <span>Facebook</span></a></li>
						<li><a href="#"><i class="icon-instagram"></i> <span>Instagram</span></a></li>
						<li><a href="#"><i class="icon-google"></i> <span>Google Plus</span></a></li>
					</ul>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12 fh5co-copyright text-center">
					<p><small>&copy; 2018 Tribal affairs of India. All Rights Reserved. </small> <small>Made  by Government of India </small></p>
				</div>
			</div>
		</div>
	</footer>
	
	<!-- jQuery -->
	<script src="js/jquery.min.js"></script>
	<!-- jQuery Easing -->
	<script src="js/jquery.easing.1.3.js"></script>
	<!-- Bootstrap -->
	<script src="js/bootstrap.min.js"></script>
	<!-- Waypoints -->
	<script src="js/jquery.waypoints.min.js"></script>
	<!-- Stellar -->
	<script src="js/jquery.stellar.min.js"></script>
	<!-- Google Map -->
	<!--
	<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCefOgb1ZWqYtj7raVSmN4PL2WkTrc-KyA&sensor=false"></script>
	<script src="js/google_map.js"></script> -->
	
    
	<!-- MAIN JS -->
	<script src="js/main.js"></script>
<!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
	</body>
</html>
<?php
if(isset($_POST['name']))
{
	$name=$_POST['name'];
}
if(isset($_POST['email']))
{
	$email=$_POST['email'];
}
if(isset($_POST['subject']))
{
	$subject=$_POST['subject'];
}
if(isset($_POST['message']))
{
	$message=$_POST['message'];
}
if (isset($_POST['submit'])) {
}
if (empty($name)==false AND empty($email)==false AND empty($message)==false AND empty($subject)==false)
{
	$headers="From:".$email;
	$content= "Hi,This is ".$name." From:".$email.'.'.$message;
	//mail('vikneshwararb@gmail.com',$subject,$content,$headers);
	if(mail('vikneshwararb@gmail.com',$subject,$content,$headers))
	{
		echo'<div class="alert alert-success">Mail is sent successfully</div>';
	}
}
?>

