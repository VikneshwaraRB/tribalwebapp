<?php
if(isset($_POST['name']))
{
	$name=$_POST['name'];
}
if(isset($_POST['email']))
{
	$email=$_POST['email'];
}
if(isset($_POST['subject']))
{
	$subject=$_POST['subject'];
}
if(isset($_POST['message']))
{
	$message=$_POST['message'];
}
if (isset($_POST['submit'])) {
echo'<div class="alert alert-success">Your form is submitted</div>';
}
if (empty($name)==false AND empty($email)==false AND empty($message)==false AND empty($subject)==false)
{
	$headers="From:".$email;
	$content= "Hi,This is ".$name." From:".$email.'.'.$message;
	//mail('vikneshwararb@gmail.com',$subject,$content,$headers);
	if(mail('vikneshwararb@gmail.com',$subject,$message,$headers))
	{
		echo'<div class="alert alert-success">Mail is sent successfully</div>';
	}
}
?>