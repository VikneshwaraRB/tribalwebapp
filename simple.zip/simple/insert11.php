<?php
if(isset($_POST['aadharno']))
{
		$aadharno=$_POST['aadharno'];
}
if(isset($_POST['dob']))
{
	$dob=$_POST['dob'];

}
if(isset($_POST['state']))
{
	$state=$_POST['state'];
}	
if(isset($_POST['tribe']))
{
	$tribe=$_POST['tribe'];
}
if(isset($_POST['username']))
{
	$username=$_POST['username'];
}
if(isset($_POST['password']))
{
	$password=$_POST['password'];
}
/*
echo "CONNECTED"."</br>";
echo $aadharno."</br>";
echo $dob."</br>";
echo $state."</br>";
echo $tribe."</br>";
echo $username."</br>";
echo $password."</br>";

*/
$conn = mysqli_connect("localhost","root","","sih");

if(!$conn){
	die("could not connect".mysqli_error());
}
else{
	$sql= "INSERT INTO insertdata(aadhar,dob,state,tribe,username,password)VALUES('$aadharno','$dob','$state','$tribe','$username','$password')";
	$result=mysqli_query($conn,$sql);
	//echo $result;
	if($result==1){
		
		echo "success";

	}
	else{
	   echo "fail".mysqli_error($conn);
				 if($row['aadharno']== $aadharno )
		 {
			 echo "Id cant be same";
		 }
	}
	mysqli_close($conn);

}

?>
<a href="login.php">
<br> Return to login page </a>
  <script>
   var x =myfunction(5,6)
    function myfunction (a,b)
	{
		 return a*b ;
		 document.write(x);
	}
</script>