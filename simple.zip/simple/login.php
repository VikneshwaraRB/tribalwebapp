<!DOCTYPE html>
<html>
<head>
  <title>  LOGIN </title>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
<!-- Optional theme -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">
<meta charset="utf-8" />
<meta http-equiv="Content-type" content="text/html" charset="utf-8" />
<meta name="viewport" content="width=device-width,initial-scale=1" />
<style>
.loginform{
    border: 1px solid grey;
    border-radius: 10px;
    margin-top: 20px;
  }
  form{
    padding-bottom: 20px;
  }
</style>
</head>
<body>
<div class="container">
  <div class="row">
    <div class="col-md-6 col-md-offset-3 loginForm">
<h2><font face="ArialBlack" > LOGIN </h2> </font>
<form action= "process.php" method="POST">
<div class="form-group">
    <label for="username">Name</label>
    <input type="text" name="username" id="name" class="form-control" placeholder="Enter the username" required />
  </div>
<div class="form-group">
    <label for="password">Name</label>
    <input type="password" name="password" id="password" class="form-control" placeholder="Enter the password" required />
  </div>
<input type="submit" class="btn btn-success btn-lg" value="Login" name="submit"/>
<button type="button" onclick="register.php" class="tn btn-success btn-lg" name="register">Register</button>
</form>
    </div>
  </div>
</div>
<!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
</body>
</html>  