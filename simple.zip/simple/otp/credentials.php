<?php 
define("API_KEY", 'FGV+aE5p5hE-xpr0xGrcowbHR6kXvgpmwKMUVFgJLL');

 ?>