<!DOCTYPE html>
<html>
<head>
	<title>OTP</title>
	<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">
<meta charset="utf-8" />
<meta http-equiv="Content-type" content="text/html" charset="utf-8" />
<meta name="viewport" content="width=device-width,initial-scale=1" />	
</head>
<body>
<div class="container">
<h1 class="text-center">OTP registration</h1>
<hr>
  <div class="row">
  	<div class="col-md-9 col-md-offset-2">
  		<?php 
         if (isset($_POST['sendopt'])) {
         require ('textlocal.class.php');
             require ('credentials.php');
         $textlocal=new TextLocal(false,false,API_KEY);
         $numbers=array($_POST['mobile']);
         $sender='TXTLCL';
         $otp=mt_rand(10000,99999);
         $message="Hello.This your OTP".$otp;
         try
         {
         	$result=$textlocal->sendSms($numbers,$message,$sender);
         	setcookie('otp',$otp);
         	echo "OTP is sent successfully";
         } catch(Exception $e)
         {
         	die('Error:'.$e->getMessage());
         }
       }
       if(isset($_POST['verifyotp']))
       {
       	$otp=$_POST['otp'];
       	if ($_COOKIE['otp']==$otp) {
       	 echo "Your mobile number is verified";
       	}
       	else
       	{
       		echo "Please enter the correct OTP";
       	}
       }
  		 ?>
  	</div>
  	<div class="col-md-9 col-md-offset-2">
  		<form role="form" method="post" enctype="multipart/form-data">
  			<div class="row">
  				<div class="col-sm-9 form-group">
  					<label for="mobile">Mobile</label>
  					<input type="text" class="form-control" id="mobile" name="mobile" maxlength="10" placeholder="Enter the valid mobile number" required>
  				</div>
  			</div>
  			<div class="row">
  				<div class="col-sm-9 form-group">
  					<button type="submit" name="sendopt" class="btn btn-lg btn-success">Send OTP</button>
  				</div>
  			 </div>	
  		</form>
  		<form method="POST" action="">
  			<div class="row">
  				<div class="col-sm-9 form-group">
  					<label for="otp">OTP</label>
  					<input type="text" name="otp" id="otp" class="form-control" placeholder="Enter your OTP number" required>
  				</div>
  			</div>
  			<div class="row">
  				<div class="col-sm-9 form-group">
  					<button type="submit" name="verifyotp" class="btn btn-lg btn-info btn-block">Verify</button> 
  				</div>
  			</div>
  		</form>
  	</div>
  </div>
</div>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
</body>
</html>