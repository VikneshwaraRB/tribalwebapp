 <?php
if(isset($_POST['username'])){
		$username=$_POST['username'];
}
if(isset($_POST['password'])){
	$password=$_POST['password'];

}
$conn = mysqli_connect("localhost","root","111","tribal");
if(!$conn){
	die("could not connect".mysqli_error());
}
else
{
	 echo "connected";
} 

echo $result=mysqli_query($conn,"select * from register where username ='$username'and password ='$password'")
	        or die("Failed to query database".mysqli_error());	
		echo '<br>';
		//echo '$result';
	$row=mysqli_fetch_array($result);
	 if ($row['username']== $username && $row['password']== $password)
	{
       echo "Profile ID:- $username";	
	  
    }  
    else
	{
		echo"Failed to Login";
	}	 
/*$sql="select * from login where username ='$username'and password='$password'";
echo $sql;
$result=mysqli_query($conn,$sql);
if($result != 0) {
		echo "Login Succesfully";
} else {
       echo "Failed to login";	
}*/
?>	 
