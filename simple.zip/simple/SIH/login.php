<!DOCTYPE html>
<html>
<body style="background-color:cyan;">
<title>  LOGIN </title>
<center>
<br><br><br><br><br><br><br>
<h2><font face="ArialBlack" > LOGIN </h2> </font>
<form action= "process.php" method="POST">
<b>UserName:</b>
<input type="text" name="username" required><br><br>
<b>Password:</b>
<input type="password" name="password" required >
<br> <br>
<button type="submit">Login</button>
<style>
</style>
<button type="button" onclick="register.php">Register</button>
<br><br>
  <a href="register.php"> Click here to register </a>
  <br>
  <br>
  <script>
   var x =myfunction(5,6)
    function myfunction (a,b)
	{
		 return a*b ;
		 document.write(x);
	}
</script>
<center>
</form>
</body>
</html>  